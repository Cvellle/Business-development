import "../styles/main.scss";
import "./modules/slider.js";
import "./modules/loadSliderImages.js";
import "./modules/mobileNavToggle.js";
import "./modules/headerTranslate.js";
import "./modules/startCounterOnScroll.js";
